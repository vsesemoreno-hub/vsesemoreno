# Victoria Sese Moreno — Portfolio

Professional portfolio for AI Training, Data Annotation, AI Content Evaluation and Data Quality applications.

Publish index.html with GitHub Pages or another static hosting service.